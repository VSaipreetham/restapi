package main

import (
	"encoding/json"
	"fmt"
	"log"
	"net/http"
)

type User struct {
	Id       string `json:"Id"`
	Name     string `json:"Name"`
	Password string `json:"Password"`
}

var Users []User

func homePage(w http.ResponseWriter, r *http.Request) {
	fmt.Fprintf(w, "Welcome to the HomePage!")
}

func handleRequests() {
	http.HandleFunc("/", homePage)
	http.HandleFunc("/users", returnAllUsers)
	log.Fatal(http.ListenAndServe(":8080", nil))
}

func returnAllUsers(w http.ResponseWriter, r *http.Request) {
	fmt.Println("Endpoint Hit: returnAllUsers")
	json.NewEncoder(w).Encode(Users)
}

func main() {
	Users = []User{

		{Id: "1", Name: "Sai preetham", Password: "12"},
		{Id: "2", Name: "Sai", Password: "123"},
		{Id: "3", Name: "Vsp", Password: "1234"},
		{Id: "4", Name: "Rohit sharma", Password: "12345"},
		{Id: "5", Name: "Mahesh babu", Password: "12346"},
		{Id: "6", Name: "Prabhas", Password: "12347"},
		{Id: "7", Name: "NTR", Password: "12348"},
		{Id: "8", Name: "Allu arjun", Password: "12349"},
	}
	handleRequests()
}
