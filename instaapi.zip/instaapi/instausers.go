package main


func main()
{
	fmt.Println("Hi Welcome World");
}
